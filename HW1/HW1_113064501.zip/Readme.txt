python version: 3.8.20
compile command: python HW1.py